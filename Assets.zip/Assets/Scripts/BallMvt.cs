using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallMvt : MonoBehaviour
{
    // Start is called before the first frame update
    public float speed;
    private Rigidbody rb;

    void Start()
    {
        rb = this.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 acc= Input.acceleration;

        if (acc.z > .6)
        {
            rb.AddForce(0, 0, speed * 10000 * Time.deltaTime);
        }
        //SoundManager.playBallSound();
        /*if(Input.GetKeyUp(KeyCode.Return))
        {
            rb.AddForce(0, 0, speed * 100000 * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            rb.transform.Translate(-2 * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            rb.transform.Translate(2 * Time.deltaTime, 0, 0);
        }*/
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Pin")
        {
            Handheld.Vibrate();
            SoundManager.playStrikeSound();
        }
    }
}
